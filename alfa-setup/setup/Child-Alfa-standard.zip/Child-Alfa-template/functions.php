<?php
/*================================================
#Load the translations from the child theme folder
================================================*/
function wpcninja_translation() {
  load_textdomain( 'Divi', get_stylesheet_directory() . '/lang/theme/Divi-bg_BG.mo' );
  load_textdomain( 'et_builder', get_stylesheet_directory() . '/lang/builder/et_builder-bg_BG.mo' );
  }
add_action( 'after_setup_theme', 'wpcninja_translation' );